import path from "path";

import { NextResponse } from "next/server";
import fs from 'fs';
import { pipeline } from 'stream';
import { promisify } from 'util';
const pump = promisify(pipeline);
import { v4 as guid } from "uuid";
import * as imglyRemoveBackground from "@imgly/background-removal-node"
 console.log("imglyRemoveBackground ", imglyRemoveBackground);


export async function POST(req, res) {
  try {
    const formData = await req.formData();
    const file = formData.getAll('image')[ 0 ]
    console.log("file ", file);
    const fileName = guid() + "_" + file.name;
    console.log("fileName ", fileName);
    const filePath = path.resolve(process.cwd(), `./public/uploads/${fileName}`);
    console.log("filePath ", filePath);
    const res = await pump(file.stream(), fs.createWriteStream(filePath));
    const imageFile = fs.readFileSync(filePath, 'binary');
    console.log("imageFile ", imageFile);
    const fileName2 = guid() + "_" + file.name;
    console.log("fileName2 ", fileName2);
    const filePath2 = path.resolve(process.cwd(), `./public/uploads/${fileName2}`);
    console.log("filePath2 ", filePath2);
    const imageUrl = [
      "http://localhost:3000",
      "uploads",
      fileName
    ].join("/");
    console.log("imageUrl ", imageUrl);
    const converted = await imglyRemoveBackground.removeBackground(imageFile, {
      debug: true,
      progress: console.log,
      device: "cpu",
      // model: "u2net",
      // rescale: 1,
      output: {
        format: "image/png",
        quality: 1,
      },
      // publicPath: "http://localhost:59922/",
      // output: filePath2
    })
    console.log("converted ", !!converted);
    fs.writeFileSync(filePath2, converted);

    return NextResponse.json({
      status: "success",
      data: {
        imageUrl: fileName,
        imageUrl2: fileName2
      }
    })
  }
  catch (e) {
    return NextResponse.json({ status: "fail", data: e })
  }
}
